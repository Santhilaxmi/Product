﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAPI_Product.Models
{
    public class OrderViewModel
    {
        public int Id { get; set; }
        public DateTime order_date { get; set; }
        public int cust_id { get; set; }
    }
}
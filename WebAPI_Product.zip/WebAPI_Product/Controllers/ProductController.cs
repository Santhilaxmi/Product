﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI_Product.Models;

namespace WebAPI_Product.Controllers
{
    public class ProductController : ApiController
    {
        //GET - Retrive Data
        public IHttpActionResult GetAllProducts()
        {
            IList<ProductViewModel> products = null;
            using (var x = new WebAPI_ProductEntities())
            {
                products = x.Products
                            .Select(p => new ProductViewModel()
                            {
                                Id = p.id,
                                Description = p.description,
                                Price = (decimal)p.price
                            }).ToList<ProductViewModel>();
            }

            if (products.Count == 0)
                return NotFound();

            return Ok(products);
        }

        //GET - Retrive particular Data
        public IHttpActionResult GetProduct(int id)
        {
            if (id <= 0)
                return BadRequest("Please enter valid Product Id");

            IList<ProductViewModel> product = null;
            using (var x = new WebAPI_ProductEntities())
            {
                product = x.Products
                                .Where(p => p.id == id)
                                .Select(p => new ProductViewModel()
                                {
                                    Id = p.id,
                                    Description = p.description,
                                    Price = (decimal)p.price
                                }).ToList<ProductViewModel>();
            }

            if (product.Count == 0)
                return NotFound();

            return Ok(product);
        }

        //POST - Insert Data
        public IHttpActionResult PostNewProduct(ProductViewModel product)
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");

            using (var x = new WebAPI_ProductEntities())
            {
                x.Products.Add(new Product()
                {
                    description = product.Description,
                    price = product.Price
                });

                x.SaveChanges();
            }

            return Ok();
        }

        //PUT - Update Data
        public IHttpActionResult PutProduct(ProductViewModel product)
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");
            using (var x = new WebAPI_ProductEntities())
            {
                var checkExistingProduct = x.Products.Where(p => p.id == product.Id).FirstOrDefault<Product>();

                if (checkExistingProduct != null)
                {
                    checkExistingProduct.description = product.Description;
                    checkExistingProduct.price = product.Price;

                    x.SaveChanges();
                }
                else
                    return NotFound();
            }

            return Ok();
        }

        //DELETE - Delete Data
        public IHttpActionResult Delete(int id)
        {
            if (id <= 0)
                return BadRequest("Please enter valid Product Id");

            using (var x = new WebAPI_ProductEntities())
            {
                var product = x.Products
                                .Where(p => p.id == id)
                                .FirstOrDefault();

                x.Entry(product).State = System.Data.Entity.EntityState.Deleted;
                x.SaveChanges();
            }

            return Ok();
        }
    }
}

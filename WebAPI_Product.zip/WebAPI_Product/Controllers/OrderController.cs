﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI_Product.Models;

namespace WebAPI_Product.Controllers
{
    public class OrderController : ApiController
    {
        //GET - Retrive Data
        public IHttpActionResult GetAllOrders()
        {
            IList<OrderViewModel> orders = null;
            using (var x = new WebAPI_ProductEntities())
            {
                orders = x.Orders
                            .Select(o => new OrderViewModel()
                            {
                                Id = o.id,
                                order_date = (DateTime)o.order_date,
                                cust_id = (int)o.cust_id
                            }).ToList<OrderViewModel>();
            }

            if (orders.Count == 0)
                return NotFound();

            return Ok(orders);
        }

        //GET - Retrive particular Data
        public IHttpActionResult GetOrder(int id)
        {
            if (id <= 0)
                return BadRequest("Please enter valid Product Id");

            IList<OrderViewModel> order = null;
            using (var x = new WebAPI_ProductEntities())
            {
                order = x.Orders
                                .Where(o => o.id == id)
                                .Select(o => new OrderViewModel()
                                {
                                    Id = o.id,
                                    order_date = (DateTime)o.order_date,
                                    cust_id = (int)o.cust_id
                                }).ToList<OrderViewModel>();
            }

            if (order.Count == 0)
                return NotFound();

            return Ok(order);
        }

        //POST - Insert Data
        public IHttpActionResult PostNewOrder(OrderViewModel order)
        {
            if (!ModelState.IsValid)
                return BadRequest("Invalid data.");

            using (var x = new WebAPI_ProductEntities())
            {
                x.Orders.Add(new Order()
                {
                    order_date = order.order_date,
                    cust_id = order.cust_id
                });

                x.SaveChanges();
            }

            return Ok();
        }

        //DELETE - Delete Data
        [HttpDelete]
        public IHttpActionResult Delete(int id)
        {
            if (id <= 0)
                return BadRequest("Please enter valid Order Id");

            using (var x = new WebAPI_ProductEntities())
            {
                var order = x.Orders
                                .Where(o => o.id == id)
                                .FirstOrDefault();

                x.Entry(order).State = System.Data.Entity.EntityState.Deleted;
                x.SaveChanges();
            }

            return Ok();
        }
    }
}
